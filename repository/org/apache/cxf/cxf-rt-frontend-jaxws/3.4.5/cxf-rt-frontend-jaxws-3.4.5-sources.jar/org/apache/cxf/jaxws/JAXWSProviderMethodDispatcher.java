/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.cxf.jaxws;

import java.lang.reflect.Method;

import javax.xml.ws.Provider;

import org.apache.cxf.common.util.ReflectionUtil;
import org.apache.cxf.endpoint.Endpoint;
import org.apache.cxf.jaxws.support.JaxWsImplementorInfo;
import org.apache.cxf.service.factory.ServiceConstructionException;
import org.apache.cxf.service.model.BindingOperationInfo;
import org.apache.cxf.service.model.OperationInfo;

public class JAXWSProviderMethodDispatcher
    implements org.apache.cxf.service.invoker.MethodDispatcher {

    Method invoke;

    public JAXWSProviderMethodDispatcher(JaxWsImplementorInfo implInfo) {
        try {
            invoke = ReflectionUtil.getMethod(implInfo.getImplementorClass(), "invoke", 
                                              new Class[] {implInfo.getProviderParameterType()});
            ReflectionUtil.setAccessible(invoke);
        } catch (Exception e1) {
            //fall back to the raw Provider provided invoke method
            try {
                invoke = Provider.class.getMethod("invoke", new Class[] {Object.class});
            } catch (Exception e) {
                throw new ServiceConstructionException(e);
            }
        }
    }

    public BindingOperationInfo getBindingOperation(Method m, Endpoint endpoint) {
        return null;
    }

    public Method getMethod(BindingOperationInfo op) {
        return invoke;
    }

    public void bind(OperationInfo o, Method... methods) {
    }


}
