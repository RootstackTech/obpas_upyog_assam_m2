package org.jgroups.tests;

import org.jgroups.JChannel;
import org.jgroups.blocks.RequestOptions;
import org.jgroups.blocks.RpcDispatcher;
import org.jgroups.util.RspList;
import org.jgroups.util.Util;

/**
 * @author Bela Ban
 * @since x.y
 */
public class bla8a {
    protected JChannel a, b;
    protected RpcDispatcher disp1, disp2;
    protected int counter=1;

    public int foo() {
        return counter++;
    }

    protected void start() throws Exception {
        a=new JChannel(Util.getTestStack()).name("A");
        disp1=new RpcDispatcher(a, this);
        a.connect("demo");
        b=new JChannel(Util.getTestStack()).name("B");
        disp2=new RpcDispatcher(b, this);
        b.connect("demo");
        Util.waitUntilAllChannelsHaveSameSize(10000, 500, a,b);

        while(true) {
            Util.keyPress("<enter>");
            RspList<Object> rsps=disp1.callRemoteMethods(null, "foo", null, null, RequestOptions.SYNC());
            System.out.println("rsps =\n" + rsps);
        }
    }

    public static void main(String[] args) throws Exception {
        new bla8a().start();

    }



}
