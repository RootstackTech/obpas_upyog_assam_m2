package org.jgroups.tests;

/**
 * @author Bela Ban
 * @since x.y
 */
public class bla4 {
    public static void main(String[] args) throws Exception {
        short s;

        s=toPositiveUnsignedShort(Short.MAX_VALUE+1);
        System.out.println("s = " + s);



    }

    protected static short toPositiveUnsignedShort(int num) {
        if(num < 0 || num > Short.MAX_VALUE) {
            short tmp=(short)num;
            throw new IllegalArgumentException(String.format("number %d must be a positive unsigned short", tmp));
        }
        return (short)num;
    }
}
