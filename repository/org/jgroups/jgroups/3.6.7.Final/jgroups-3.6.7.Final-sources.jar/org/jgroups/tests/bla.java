package org.jgroups.tests;

import org.jgroups.nio.Buffers;
import org.jgroups.nio.MockSocketChannel;

import java.nio.ByteBuffer;

/**
 * @author Bela Ban
 * @since x.y
 */
public class bla {
    public static void main(String[] args) throws Exception {
        MockSocketChannel ch=new MockSocketChannel()
          .bytesToRead((ByteBuffer)ByteBuffer.allocate(4).putInt(500).flip());
        Buffers bufs=new Buffers(ByteBuffer.allocate(4));
        while(true) {
            boolean rc=bufs.read(ch);
            if(!rc)
                break;
        }

    }




}
