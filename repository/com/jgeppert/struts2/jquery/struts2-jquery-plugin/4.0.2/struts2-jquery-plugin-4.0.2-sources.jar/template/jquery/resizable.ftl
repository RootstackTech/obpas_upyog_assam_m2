<#--
/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
-->
<#assign escapedOptionId="${parameters.id?string?replace('.', '_')}">
  <#if parameters.resizable?default(false)>
	options_${escapedOptionId?html}.resizable = true;<#rt/>
   </#if>
  <#if parameters.resizableOptions?if_exists != "">
 	options_${escapedOptionId?html}.resizableoptions = "${parameters.resizableOptions?html}";<#rt/>
   </#if>
  <#if parameters.resizableOnResizeTopics?if_exists != "">
	options_${escapedOptionId?html}.resizableonresizetopics = "${parameters.resizableOnResizeTopics?html}";<#rt/>
   </#if>
  <#if parameters.resizableOnStartTopics?if_exists != "">
	options_${escapedOptionId?html}.resizableonstarttopics = "${parameters.resizableOnStartTopics?html}";<#rt/>
   </#if>
  <#if parameters.resizableOnStopTopics?if_exists != "">
	options_${escapedOptionId?html}.resizableonstoptopics = "${parameters.resizableOnStopTopics?html}";<#rt/>
   </#if>
