package com.fasterxml.jackson.datatype.hibernate5;

import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.core.Versioned;
import com.fasterxml.jackson.core.util.VersionUtil;

/**
 * Automatically generated from PackageVersion.java.in during
 * packageVersion-generate execution of maven-replacer-plugin in
 * pom.xml.
 */
public final class PackageVersion implements Versioned {
    public final static Version VERSION = VersionUtil.parseVersion(
        "2.9.2", "com.fasterxml.jackson.datatype", "jackson-datatype-hibernate5");

    @Override
    public Version version() {
        return VERSION;
    }
}
